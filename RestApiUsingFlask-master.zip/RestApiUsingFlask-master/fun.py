def sum(a,b):
    return a+b

def avg(a,b):
    return (a+b)/2

